package com.example.yukamalcoba.network

class Services{
    private val api: MosqueApi=
}