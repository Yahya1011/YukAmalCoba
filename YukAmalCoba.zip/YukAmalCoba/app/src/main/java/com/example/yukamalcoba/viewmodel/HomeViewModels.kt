package com.example.yukamalcoba.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.yukamalcoba.model.Masjid

class HomeViewModels : ViewModel(){
    val masjid = MutableLiveData<List<Masjid>>()

    val masjidLoadError = MutableLiveData<Boolean>()

    val loading = MutableLiveData<Boolean>()

    fun refresh(){
        fecthMasjid()
    }

    private fun fecthMasjid() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}