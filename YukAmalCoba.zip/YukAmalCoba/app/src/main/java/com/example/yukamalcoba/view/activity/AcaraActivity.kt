package com.example.yukamalcoba.view.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.yukamalcoba.R

class AcaraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_acara)
    }
}