package com.example.yukamalcoba.network

import com.example.yukamalcoba.BuildConfig

object ApiEndPoint {
    val END_POINT_PATH = BuildConfig.BASE_URL
}