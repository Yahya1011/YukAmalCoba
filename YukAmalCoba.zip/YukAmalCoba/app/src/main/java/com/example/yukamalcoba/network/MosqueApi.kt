package com.example.yukamalcoba.network

import android.graphics.drawable.Drawable
import retrofit2.http.GET

interface MosqueApi {
    @GET (MOSQUE)
}
