package com.example.yukamalcoba.utils.extention

import android.widget.ImageView
import androidx.swiperefreshlayout.widget.CircularProgressDrawable

internal fun ImageView.loadImage( url:String, progressDrawable: CircularProgressDrawable){

}